    void ATD_init(void);
unsigned int ATD_read(void);
unsigned int myreading,myvoltage;
#define ClockFreq 8000000 //8Mghz Fosc
#define TMR2PRESCALE 16
    //  unsigned int myreading;
 // unsigned char myVoltage;
long PWM_freq = 5000;  // periiod = 0.2us

   void PWM_Initialize()
{
PR2 = (ClockFreq / (PWM_freq*4*TMR2PRESCALE)) - 1; //24//Setting the PR2 formulae using Datasheet // Makes the PWM work in 5KHZ
CCP1M3_bit = 1; CCP1M2_bit = 1;  //Configure the CCP1 module
T2CKPS0_bit = 1;T2CKPS1_bit = 0; TMR2ON_bit = 1; //Configure the Timer module
TRISC2_bit = 0; // make port pin on C as output
}


void PWM_Duty(unsigned int duty)
{
 if(duty<1023)
  {
    duty = ((float)duty/1023)*(ClockFreq/(PWM_freq*TMR2PRESCALE)); // On reducing //duty = (((float)duty/1023)*(1/PWM_freq)) / ((1/_XTAL_FREQ) * TMR2PRESCALE);
    CCP1X_bit = duty & 1; //Store the 0st bit
    CCP1Y_bit = duty & 2; //Store the 1th bit
    CCPR1L = duty>>2;// Store the remining 8 bit
  }
}


void ATD_init(void){
 ADCON0 = 0x41;
 ADCON1 = 0xCE;
 TRISA = 0x01; }

unsigned int ATD_read(void){
 ADCON0 = ADCON0 | 0x04;
 while(ADCON0 & 0x04);
 return((ADRESH<<8) | ADRESL); }




void main() {
 TRISB = 0x00;
 PORTB = 0x00;
 ATD_init();

 while(1){
 myreading = ATD_read();
  myvoltage= ( myreading*50)/1023;

  if(myVoltage<=20){PWM_Duty(0); }
if(myVoltage>=20 && myVoltage<=30){PWM_Duty(50); PORTB = 0x00;}

if(myVoltage>=30 && myVoltage<=40){PWM_Duty(500); PORTB = 0xff;}
if(myVoltage>=40 && myVoltage<=50){PWM_Duty(900);PORTB = 0xFF; }
 //if(myreading >=0 && myreading <=30) PORTB = 0x00;
  // if(myreading >=30 && myreading <=50) PORTB = 0xFF;
 }
 }