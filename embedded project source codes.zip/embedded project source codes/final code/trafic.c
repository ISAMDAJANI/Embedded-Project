// ========================================================== Global Variables ==========================================================

unsigned char EchoStartEnd = 0;
unsigned int OverFlow = 0;
unsigned int EchoTime = 0;
unsigned char Distance = 0;
unsigned int Delay_Counter = 0;
unsigned char waste = 0;

// ========================================================== Global Variables ==========================================================

void msDelay(unsigned int Time)
{
 TMR0 = 6;


 Delay_Counter = 0;
 Time = Time * 4;

 while (Delay_Counter < Time);
}


void SendTrigger(void)
{
 PORTC = PORTC | 0x01;
 waste++; waste++; waste++; waste++; waste++; waste++; waste++; waste++; waste++; waste++;
 waste++; waste++; waste++; waste++; waste++; waste++; waste++; waste++; waste++; waste++;
 PORTC = PORTC & 0xFE;
}


// ========================================================== Interrupts ==========================================================
void Interrupt(void)
{

 // **************** RB0 External Interrupt ****************
 if(INTCON & 0x02)
 {
  if(EchoStartEnd == 0)
  {

   TMR0 = 6;

   OverFlow = 0;
   OPTION_REG = OPTION_REG & 0xBF;
   EchoStartEnd++;
  }
  else
  {

   EchoTime = (OverFlow * 250) + (TMR0 - 6);

   Distance = (17 * EchoTime)/1000;





   OPTION_REG = OPTION_REG | 0x40;

   EchoStartEnd = 0;
  }
  INTCON = INTCON & 0xFD;
 }

 // **************** Timer0 over-flow Interrupt ****************
 if(INTCON & 0x04)
 {
  TMR0 = 6;

  OverFlow++;
  Delay_Counter++;
  INTCON = INTCON & 0xFB;
 }
}
// ========================================================== Interrupts ==========================================================

void main()
{
 TRISB = 0xFF;
 TRISC = 0x00;
 PORTC = 0x00;
 TRISD = 0x00;
 PORTD = 0x00;

 INTCON = 0xB0;
 OPTION_REG = 0x40;



 while(1)
 {
  SendTrigger();

  if(Distance < 10)
  {
   PORTD = 0x04;
   msDelay(250);
  }
  else
  {
   PORTD = 0x01;
   msDelay(250);
  }
 }
}