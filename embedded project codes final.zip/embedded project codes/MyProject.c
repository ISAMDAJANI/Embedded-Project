 unsigned char myButton, myDirection;
void interrupt(void){
 TMR0 = 178;

 if(PORTC & 0x01) myButton=1;
 else if(PORTC & 0x02) myButton =2;
 else if (PORTC & 0x04) myButton =3;
 if(PORTC & 0x08) myDirection = ~myDirection;

 INTCON = INTCON & 0xFB;}
void main() {
TRISC = 0xFF;
TRISB = 0x00;
TRISD = 0x00;
ADCON1 =0x06;
TRISA = 0x00;
PORTA = 0x0F;
myButton=0;
myDirection=0;
OPTION_REG = 0x07;
TMR0 =178;
INTCON = 0xA0;
while(1){
while ((PORTC &0x10)==0 ){PORTB=0x00;}
//else{
 if(myButton == 1){
 if(myDirection) PORTB = 0x05;
 else PORTB = 0x0A;

 }
 if(myButton == 2){


 if(TMR0<178+39){
 if(myDirection) PORTB =0x05;
 else PORTB = 0x0A;
 }else{
 PORTB = 0x00;
 }

 }
 if(myButton == 3){
 PORTB = 0x00;

 } } }